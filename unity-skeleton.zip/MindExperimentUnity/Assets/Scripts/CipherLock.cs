using System;using System.Linq;
public class CipherLock{
    public string Id, Title; public string[] Answers;
    public bool Try(string a){
        a=(a??"").Trim().ToLowerInvariant();
        return Answers.Any(x=>x==a);
    }
    public static CipherLock[] All=new[]{
        new CipherLock{Id="s1",Title="AYNALAR KAPISI",Answers=new[]{"dolunayekspres","dolunay ekspres"}},
        new CipherLock{Id="s2",Title="LUNARIS — GÖL",Answers=new[]{"yaldabaoth"}},
        new CipherLock{Id="s5",Title="ARŞİV",Answers=new[]{"1969"}},
        new CipherLock{Id="s4",Title="LABİRENT",Answers=new[]{"balance","denge"}},
        new CipherLock{Id="s6",Title="İSTASYON",Answers=new[]{"12 nisan 2025","12042025","120425"}},
        new CipherLock{Id="s7",Title="YALDABAOTH ÇEKİRDEĞİ",Answers=new[]{"stop yaldabaoth","stopyaldabaoth","dur yaldabaoth"}},
    };
}
