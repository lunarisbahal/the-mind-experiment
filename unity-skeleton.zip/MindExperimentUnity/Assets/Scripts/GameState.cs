using System;using System.IO;using UnityEngine;
[Serializable]
public class GameState{
    public int locks, stage, insight; public float lucidity=100f;
    public bool integrated, initiate, coreDown;
    public string reading="", playerName="";
    public bool[] rites=new bool[7];
    public int echoes, plaques;
    static string PathFile=>System.IO.Path.Combine(Application.persistentDataPath,"it041_save.json");
    public static GameState Load(){
        try{ if(File.Exists(PathFile)) return JsonUtility.FromJson<GameState>(File.ReadAllText(PathFile)); }catch{}
        return new GameState();
    }
    public void Save(){ try{ File.WriteAllText(PathFile, JsonUtility.ToJson(this)); }catch{} }
    public void RegenLucidity(float dt,bool daylight,bool fullMoon){
        lucidity=Mathf.Min(100f, lucidity + dt*(daylight?1.1f:0.35f)*(fullMoon?1.6f:1f));
    }
}
