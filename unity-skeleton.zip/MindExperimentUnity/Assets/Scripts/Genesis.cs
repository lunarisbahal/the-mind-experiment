using System;
[Serializable]
public class Universe{
    public string name, law, balance, time, inhabitants, manifesto, born;
    /// doğum haritası için deterministik tohum
    public int Seed(){ int s=0; foreach(var ch in name+law) s=(int)(((long)s*31+ch)%2147483647); return s; }
}
public static class Genesis{
    public static string FallbackManifesto(Universe u)=>
        $"Başlangıçta {u.name} yoktu; yalnız bir cümle vardı: \"{u.law}\" "+
        $"Cümle söylendi ve boşluk iki yakaya ayrıldı. Zaman {u.time} olarak akmaya başladı. "+
        $"Ve sakinleri geldi: {u.inhabitants}. Bütünleşen bilinç kopyalanamaz. Işık yolunu bulsun.";
}
