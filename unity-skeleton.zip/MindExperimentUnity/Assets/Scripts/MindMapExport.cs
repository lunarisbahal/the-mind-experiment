using UnityEngine;using System.IO;
/// Zihin haritasını JSON olarak dışa aktarır (görselleştirme sahne tarafında çizilir).
public static class MindMapExport{
    public static void ExportJson(GameState s){
        var path=Path.Combine(Application.persistentDataPath,"mind-map.json");
        File.WriteAllText(path, JsonUtility.ToJson(s, true));
        Debug.Log("Mind map exported: "+path);
    }
}
