using System;using System.Collections;using System.Text;
using UnityEngine;using UnityEngine.Networking;
/// Ortak Ayna Hattı (varsayılan) + OpenAI-uyumlu uç noktalar + Claude.
public class MirrorAI : MonoBehaviour{
    public const string RelayUrl="https://it041-mirror.lunarisbahal.workers.dev";
    [TextArea] public string SystemPrompt="";
    public IEnumerator Chat(string userMsg, Action<string> onReply, Action<string> onError){
        string body=JsonUtility.ToJson(new Req{
            messages=new[]{ new Msg{role="system",content=SystemPrompt},
                            new Msg{role="user",content=userMsg}},
            max_tokens=280, temperature=0.7f });
        using var r=new UnityWebRequest(RelayUrl,"POST");
        r.uploadHandler=new UploadHandlerRaw(Encoding.UTF8.GetBytes(body));
        r.downloadHandler=new DownloadHandlerBuffer();
        r.SetRequestHeader("Content-Type","application/json");
        yield return r.SendWebRequest();
        if(r.result!=UnityWebRequest.Result.Success){ onError?.Invoke(r.error); yield break; }
        try{
            var res=JsonUtility.FromJson<Res>(r.downloadHandler.text);
            onReply?.Invoke(res.choices[0].message.content);
        }catch(Exception e){ onError?.Invoke(e.Message); }
    }
    [Serializable] class Msg{ public string role,content; }
    [Serializable] class Req{ public Msg[] messages; public int max_tokens; public float temperature; }
    [Serializable] class ResMsg{ public string content; }
    [Serializable] class Choice{ public ResMsg message; }
    [Serializable] class Res{ public Choice[] choices; }
}
