using System;
public static class MoonPhase{
    static readonly DateTime NewMoonRef=new DateTime(2000,1,6,18,14,0,DateTimeKind.Utc);
    const double Synodic=29.530588853;
    public static double Phase(DateTime utc){
        double t=(utc-NewMoonRef).TotalDays/Synodic;
        return ((t%1)+1)%1; // 0=yeniay, 0.5=dolunay
    }
    public static int Bin(DateTime utc)=>(int)Math.Floor(((Phase(utc)+1.0/16)%1)*8);
    public static bool IsFull(DateTime utc)=>Bin(utc)==4;
    public static bool IsNew(DateTime utc)=>Bin(utc)==0;
    // Lunaris penceresi: 12 Nisan 2025 22:15 dolunayı
    public static readonly DateTime LunarisMoon=new DateTime(2025,4,12,22,15,0);
}
