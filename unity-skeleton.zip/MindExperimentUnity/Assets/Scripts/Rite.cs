using System;using System.Collections.Generic;
[Serializable]
public class Rite{
    public string Id,Title,Prompt; public string Answer="";
    public bool Done=>!string.IsNullOrEmpty(Answer);
    public static List<Rite> Seven()=>new List<Rite>{
        new Rite{Id="r1",Title="RİTÜEL I — DİSKİ ADLANDIR",Prompt="Hâlâ çekim gücü olan bir anını adlandır."},
        new Rite{Id="r2",Title="RİTÜEL II — BUGÜNÜN KAPTANI",Prompt="Bugün direksiyondaki maske kim?"},
        new Rite{Id="r3",Title="RİTÜEL III — YASAK İSTEK",Prompt="Söylemediğin isteği yaz."},
        new Rite{Id="r4",Title="RİTÜEL IV — İKİ EV",Prompt="Hangi pencerenin arkasında yaşıyorsun?"},
        new Rite{Id="r5",Title="RİTÜEL V — YANACAK OLAN",Prompt="Yanmasına izin vereceğin şeyi yaz."},
        new Rite{Id="r6",Title="RİTÜEL VI — İZLEYİŞ",Prompt="Altmış kalp atışı boyunca yalnızca izle."},
        new Rite{Id="r7",Title="RİTÜEL VII — SENİ İZLEYEN ŞEY",Prompt="Yumruğunu kaldır — ya da dinle. (DİNLE = bütünleşme)"},
    };
}
