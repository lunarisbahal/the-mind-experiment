using UnityEngine;
[RequireComponent(typeof(CharacterController))]
public class ThirdPersonController : MonoBehaviour{
    public Transform cam; public float speed=4.5f,runMult=1.8f,jump=5.6f,gravity=15f,turnLerp=12f;
    CharacterController cc; float vy;
    void Awake(){ cc=GetComponent<CharacterController>(); }
    void Update(){
        var inp=new Vector3(Input.GetAxis("Horizontal"),0,Input.GetAxis("Vertical"));
        var fwd=cam?Vector3.ProjectOnPlane(cam.forward,Vector3.up).normalized:Vector3.forward;
        var right=cam?cam.right:Vector3.right;
        var move=(fwd*inp.z+right*inp.x);
        if(move.sqrMagnitude>1f) move.Normalize();
        float sp=speed*(Input.GetKey(KeyCode.LeftShift)?runMult:1f);
        if(cc.isGrounded){ vy=-1f; if(Input.GetButtonDown("Jump")) vy=jump; }
        vy-=gravity*Time.deltaTime;
        cc.Move((move*sp+Vector3.up*vy)*Time.deltaTime);
        if(move.sqrMagnitude>.001f)
            transform.rotation=Quaternion.Slerp(transform.rotation,Quaternion.LookRotation(move),turnLerp*Time.deltaTime);
    }
}
