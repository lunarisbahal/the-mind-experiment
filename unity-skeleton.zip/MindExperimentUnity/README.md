# THE MIND EXPERIMENT — Unity 3D İskeleti (v1)
Dolunay Ekspres / Zihin Deneyi IT-041'in Unity (C#) iskeleti.
HTML sürümündeki çekirdek sistemlerin birebir taşınabilir karşılıkları.

## Kurulum
1. Unity Hub → New Project → 3D (URP önerilir), Unity 2022.3 LTS+
2. Assets/Scripts klasörünü projenin Assets'ine kopyala
3. Boş bir GameObject'e GameManager ekle; sahneye Player (CharacterController) koy
4. MirrorAI.RelayUrl zaten Ortak Ayna Hattı'na ayarlı — AI diyalog hazır çalışır

## Scriptler
- GameState.cs      : ilerleme (kilitler, ritüeller, içgörü, berraklık) + JSON kayıt
- MoonPhase.cs      : gerçek astronomik ay evresi (HTML ile aynı formül)
- CipherLock.cs     : ayna-yasası şifre kilitleri (6 kilit, cevap kontrolü)
- Rite.cs           : 7 ritüel + kendi ritüellerin
- MirrorAI.cs       : Ortak Ayna Hattı / Groq / Claude / Ollama istemcisi (UnityWebRequest)
- Personas.cs       : 13 karakter istemi (TR) + AJAN YASALARI
- MantraPage.cs     : Beyaz Sayfa — mantra seçkisi + frekans hesabı
- Genesis.cs        : Evren Tohumu — manifesto + deterministik doğum haritası verisi
- MindMapExport.cs  : zihin haritası verisini PNG/JSON dışa aktarma iskeleti
- ThirdPersonController.cs : basit üçüncü şahıs kontrolcü (WASD+fare+zıplama)
